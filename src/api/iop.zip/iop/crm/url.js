export default {
    findActiveOfferOffInfo: "/findActiveOfferOffInfo", // 正式
    findTCkmSegmentInfo: '/CrmProdController/findTCkmSegmentInfo', // 查询客户群id,客户群名称,引到期时间
    findTdCaCrmCampnConfigInfo: '/CrmProdController/findTdCaCrmCampnConfigInfo', // 查询目录
    findTdCaCrmCampnConfigProdInfo: '/CrmProdController/findTdCaCrmCampnConfigProdInfo' // 查询产品id，产品名称，引用客户群数量
    // findActiveOfferOffInfo: '/findActiveOfferActInfo' //  测试   
};
